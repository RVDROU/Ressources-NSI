# Commentaires

{{ py('exo_corr') }}

La fonction fait un arrêt prématuré et renvoie l'indice dès que la valeur est découverte.

Si la valeur n'est pas trouvée, la fonction renvoie `None` comme toute fonction Python qui termine sans rencontrer de `return`.
