def gelees(temperatures):
    ...





assert gelees([2, -3, -2, 0, 1, -1]) == 3
assert gelees([3, 2, 2]) == 0
assert gelees([]) == 0