VOYELLES = ['a', 'e', 'i', 'o', 'u', 'y']

def dentiste(texte):
    ...



# tests

assert dentiste("j'ai mal") == 'aia'
assert dentiste("il fait chaud") == 'iaiau'
assert dentiste("") == ''
