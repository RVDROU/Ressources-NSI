def compte_occurrences(caractere, mot):
    ...




# tests
assert compte_occurrences("e", "sciences") == 2
assert compte_occurrences("i", "mississippi") == 4
assert compte_occurrences("a", "mississippi") == 0
