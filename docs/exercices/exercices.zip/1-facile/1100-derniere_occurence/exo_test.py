# tests

assert derniere_occurrence([5, 3], 1) == 2
assert derniere_occurrence([2, 4], 2) == 0
assert derniere_occurrence([2, 3, 5, 2, 4], 2) == 3

# Autres tests

assert derniere_occurrence([1, 2, 1, 2, 1], 1) == 4
assert derniere_occurrence([1, 2, 3, 4, 5], 0) == 5
assert derniere_occurrence([1, 2, 3], 1) == 0

