def tous_differents(tableau):
    ...


# tests

tableau1 = [1, 2, 3, 6, 2, 4, 5]
assert tous_differents(tableau1) == False

tableau2 = ['chien', 'chat', 'lion', 'poisson']
assert tous_differents(tableau2) == True

