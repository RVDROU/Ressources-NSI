# Commentaires

Il s'agit d'une recherche de maximum classique. La liste étant non-vide, on initialise la `maxi` avec la première valeur.

{{ py('exo_corr', 0, '# TESTS') }}

