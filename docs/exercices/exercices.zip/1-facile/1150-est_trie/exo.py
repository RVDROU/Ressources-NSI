# Votre fonction ici



# tests

assert est_trie([0, 5, 8, 8, 9])
assert not est_trie([8, 12, 4])
assert est_trie([-1, 4])
assert est_trie([5])
assert est_trie([])
