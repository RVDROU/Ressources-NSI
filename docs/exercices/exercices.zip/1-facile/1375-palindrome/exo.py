def cree_palindrome(mot, palindrome):
    ...




# tests

assert cree_palindrome("ka", "y") == 'kayak'
assert cree_palindrome("ser", "") == 'serres'
assert cree_palindrome("r", "ada") == 'radar'
assert cree_palindrome("ar", "fettttef") == 'arfettttefra'
