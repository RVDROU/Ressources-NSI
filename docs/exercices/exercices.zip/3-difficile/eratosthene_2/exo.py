def somme_premiers(n):
    ...





# tests

assert somme_premiers(5) == 5
assert somme_premiers(20) == 77
