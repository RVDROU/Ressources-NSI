delannoy_mem = dict()

def delannoy(n, m):
    if (n, m) not in delannoy_mem:
        if (n == 0) or (...):
            resultat = ...
        else:
            resultat = ...
        delannoy_mem[(n, m)] = ...
    return ...



# tests

assert delannoy(3, 3) == 63
assert delannoy(2, 1) == 5
