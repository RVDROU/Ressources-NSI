nb_zeros_factorielle = [...]
...



# tests

assert nb_zeros_factorielle[3] == 0

assert nb_zeros_factorielle[11] == 2

assert nb_zeros_factorielle[42] == 9

assert len(nb_zeros_factorielle) >= 1000
