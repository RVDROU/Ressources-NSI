def hipparque(n):
    ...



# tests

assert hipparque(3) == 3
assert hipparque(4) == 11
assert hipparque(5) == 45
